/*
          Team: Marcel, Raphael Lawo, Patricia, Anselm
          Modul: ConfernceRoom Modul
          date: 06.06.18
          Nur zur Verwendung für das Modul: Web Engineering I Programmieraufgabe
 */

//Online-Version: loadData("jsontags.jsp") überspeichert die vordefinierten Objects;
var tagArray = {
    "status": "ok", "tags": [
        { "id": 12, "category": "Abteilung", "label": "asdhjasdhfsa", "cssClass": "tagcat1", "creationDate": "2018-05-18 9:07", "deletionDate": "2018-05-20 9:07" },
        { "id": 2, "category": "Abteilung", "label": "Buchhaltung", "cssClass": "tagcat1", "creationDate": "2018-05-18 9:07", "deletionDate": "2018-05-20 9:07" },
        { "id": 3, "category": "Abteilung", "label": "Intern", "cssClass": "tagcat1", "creationDate": "2018-05-18 9:07" },
        { "id": 4, "category": "Abteilung", "label": "Manufaktur", "cssClass": "tagcat1", "creationDate": "2018-05-18 9:07" },
        { "id": 1, "category": "Abteilung", "label": "Vertrieb", "cssClass": "tagcat1", "creationDate": "2018-05-18 9:07" },
        { "id": 11, "category": "Calendar", "label": "Corporate", "cssClass": "tagcat4", "creationDate": "2018-05-18 9:07", "deletionDate": "2018-05-20 9:07" },
        { "id": 10, "category": "Kategorie", "label": "Ablage", "cssClass": "tagcat3", "creationDate": "2018-05-18 9:07" },
        { "id": 9, "category": "Kategorie", "label": "DRINGEND", "cssClass": "tagcat3", "creationDate": "2018-05-18 9:07" },
        { "id": 8, "category": "Kategorie", "label": "WICHTIG", "cssClass": "tagcat3", "creationDate": "2018-05-18 9:07" },
        { "id": 5, "category": "Kunde", "label": "Heideldruck", "cssClass": "tagcat2", "creationDate": "2018-05-18 9:07" },
        { "id": 6, "category": "Kunde", "label": "LidlSchwarz", "cssClass": "tagcat2", "creationDate": "2018-05-18 9:07" },
        { "id": 7, "category": "Kunde", "label": "Kaufland", "cssClass": "tagcat2", "creationDate": "2018-05-18 9:07" }
    ]
}

//Online-Version: loadData("jsonevents.jsp") überspeichert die vordefinierten Objects
var jsonevents = {
    "status": "ok",
    "events": [{ "id": 2, "name": "WebEng INF17B", "owner": { "id": 1, "firstname": "Michael", "lastname": "Janich", "email": "mjanich@chimerasys.com", "role": 1 }, "tags": [{ "id": 11, "category": "Calendar", "label": "Corporate", "cssClass": "tagcat4" }], "dtStart": "2018-05-20 9:07", "dtEnd": "2018-05-20 9:07", "creationDate": "2018-05-20 9:07", "alarmMin": -1, "repeatType": "\u0000", "comment": "Letzte Vorlesung", "url": "http://www.dhbw-mosbach.de/", "location": "Mosbach" },
    { "id": 1, "name": "Betriebsfeier", "owner": { "id": 1, "firstname": "Michael", "lastname": "Janich", "email": "mjanich@chimerasys.com", "role": 1 }, "tags": [{ "id": 11, "category": "Calendar", "label": "Corporate", "cssClass": "tagcat4" }], "dtStart": "2018-05-20 9:07", "dtEnd": "2018-05-20 9:07", "creationDate": "2018-05-20 9:07", "alarmMin": 30, "repeatType": "\u006D", "comment": "Dietz", "url": "http://chimerasys.com", "repeatUntil": "2018-05-20 9:07", "location": "Stuttgart"  }]
};

/* Lädt die Daten vom Server, sofern Server antwortet */
function updateData() {
    var tags = loadData("jsontags.jsp");
    var events = loadData("jsonevents.jsp");
    if(tags != null)
        tagArray = tags;
    if(events != null)
        jsonevents = events;
}

$("div#Eingabe").toggle();

$(document).ready(function () {
    updateData();
    fillStandardFormular();
    showEvents();
    //Filter funktion für ListenAnsicht beim Löschen
    $("#myInput").on("keyup", function () {
        var value = $(this).val().toLowerCase();
        $("#EventList tr").filter(function () {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });
    //Filter funktion für ListenAnsicht beim Editieren
    $("#myInput_2").on("keyup", function () {
        var value = $(this).val().toLowerCase();
        $("#EventList_2 tr").filter(function () {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });


    $(".form_datetime").datetimepicker({
        format: "yyyy-mm-dd hh:ii",
        autoclose: true,
        todayBtn: true,
        minuteStep: 15
    });

    var slider = document.getElementById("alarmMin");
    var output = document.getElementById("wert");
    output.innerHTML = slider.value;

    slider.oninput = function () {
        output.innerHTML = this.value;
    }

});

/* Ajax zum daten runterladen der JsonEvents */
function loadData(jspFile) {
    $(document).ready(function () {
        $.get(jspFile, function (data, status) {
            if (this.status == "success" && this.readyState == 4) {
                return data.docs;
            }
        }, "json").fail(FehlerdatenLaden());
    });
}

/* Anzeige, wenn das Laden fehlgeschlagen ist*/
function FehlerdatenLaden() {
    $('#alert').html("<div class='alert alert-danger'><strong>Fehlgeschlagen!</strong> Herunterladen fehlgeschlagen.</div>");
}

/**/
function showFormular(editor) {
    var current = document.getElementById(editor);
    document.getElementById('Conference_booking').style.display =       "none";
    document.getElementById('Conference_deleteRoom').style.display =    "none";
    document.getElementById('Conference_editRoom').style.display =      "none";
    if(current != null) {
        current.style.display = "block";
        $('html:not(:animated), body:not(:animated)').animate({
        scrollTop: $(current).offset().top
        }, 500);
    }
  }

/* Rein laden der Tags in das Formular */

function fillStandardFormular() {
    var Tags = tagArray.tags;
    for (i = 0; i < Tags.length; i++) {
        document.getElementById("tags").innerHTML += "<option id='" +Tags[i].id + "'>" + Tags[i].label + "</option>";
    }
}

/* Zeigt die Listview bei dem Raum löschen an */
function showEvents() {
    var Events = jsonevents.events;
    document.getElementById('EventList').innerHTML = "";
    document.getElementById('EventList_2').innerHTML = "";
    for (i = 0; i < Events.length; i++) {
        if (Events[i] != null) {
            var id = Events[i].id;
            var event = Events[i];
            document.getElementById('EventList').innerHTML += "<tr id='" + id + "'>" +
                "<td>" + Events[i].name + "</td>" +
                "<td>" + Events[i].dtStart + "</td>" +
                "<td>" + Events[i].location + "</td>" +
                "<td>" + Events[i].comment + "</td>" +
                "<td>" + Events[i].tags[0].label + "</td>" +
                //Noch keine Löschfunktion im Backend bzw. bei SQL hinterlegt!
                "<td width='5%'><button type='button' class='btn btn-danger' onclick='deleteEvent(" + id + ")'>Löschen</button></td>" +
                "</tr>";
            document.getElementById('EventList_2').innerHTML += "<tr id='" + id + "'>" +
                "<td>" + Events[i].name + "</td>" +
                "<td>" + Events[i].dtStart + "</td>" +
                "<td>" + Events[i].location + "</td>" +
                "<td>" + Events[i].comment + "</td>" +
                "<td>" + Events[i].tags[0].label + "</td>" +
                "<td width='5%'><button type='button' class='btn btn-info' onclick='editEvent(" + id + ")'>Editieren</button></td>" +
                "</tr>";
        }
    }
}

/* Zeigt die Erinnerungs Box an */
function showAlarmSettings() {
    var checkBox = document.getElementById("erinnerung");
    // Get the output text

    // If the checkbox is checked, display the output text
    if (checkBox.checked == true) {
        document.getElementById("alarmBox").style.display = "block";
    } else {
        document.getElementById("alarmBox").style.display = "none";
    }

}

/*Löscht Event*/
function deleteEvent(eventID) {
    var Events = jsonevents.events;
    for (i = 0; i < Events.length; i++) {
        if (Events[i].id == eventID) {
            Events.splice(i, 1);
        }
    }
    showEvents();
    var serverAction = "delevent";
    $.get("update.jsp", {
        action: serverAction, name: event.name, id: event.id
    }, function (data) {
        if (!hasValue(data, status) && data.status.toLowerCase() == 'ok') {
            roomBookingSucces();
        } else {
            roomBookingFailed();
        }
    }, "json").fail(roomBookingFailed());
}

/*Editiert einen vorhanden Raumeintrag anhand seiner ID*/
function editEvent(eventID) {
    showFormular("Conference_booking");

    var Events = jsonevents.events;
    for (i = 0; i < Events.length; i++) {
        if (Events[i].id == eventID) {
            $("#betreff").val(Events[i].name);
            $("#zeitAnf").val(Events[i].dtStart);                       
            $("#zeitEnd").val(Events[i].dtEnd);                      
            $("#comment").val(Events[i].comment);
            $("#location").val(Events[i].location);
            $("#url").val(Events[i].url);
            if(Events[i].alarmMin == -1) {
                document.getElementById("erinnerung").checked = false;
            }
            else {document.getElementById("erinnerung").checked = true;}
            $("#alarmMin").val(Events[i].alarmMin); 
            document.getElementById("wert").innerHTML = Events[i].alarmMin;                       
            $("#repeatType").val(Events[i].repeatType);                 
            $("#repeatUntil").val(Events[i].repeatUntil);               
            $("#tags").val(Events[i].tags.id);                     
            showAlarmSettings();
        }
    }
}

function actionFailed() {
    document.getElementById('alert').innerHTML = "<div class='alert alert-danger'><string>Serverskript anscheinden nicht vorhanden oder keine Verbindung zum Server!</div>";
}

function actionSuccess() {
    document.getElementById('alert').innerHTML = "<div class='alert alert-success'><string>Aktion erfolgreich ausgeführt!</div>";
}
function roomBookingFailed() {
    document.getElementById('alert').innerHTML = "<div class='alert alert-danger'><string>Serverskript oder Anlegen-/Editierfunktion anscheinden nicht vorhanden oder keine Verbindung zum Server!</div>";
}

function roomBookingSuccess() {
    document.getElementById('alert').innerHTML = "<div class='alert alert-success'><string>Buchung erfolgreich!</div>";
}
function hasValue(obj) {
    return obj != null && obj != undefined && obj != "";
}


/*Update der jsonevents.jsp*/
function eventUpdate() {
    var betreff =       $("#betreff").val();
    var zeitAnf =       $("#zeitAnf").val();  
    var zeitEnd =       $("#zeitEnd").val();
    var commentar =     $("#comment").val();
    var location =      $("#location").val();
    var url =           $("#url").val();
    if(document.getElementById("erinnerung").checked == true) { var alarmMin = $("#wert").val(); }
        else {var alarmMin = -1;}
    var repeatType =    $("#repeatType").val();
    var repeatUntil =   $("#repeatUntil").val();
    var tags = $("#tags")[0].value;
    for (i = 0; i < tagArray.length; i++) {
        if(tagArray[i].label == tags.label)
            var tags = tagArray[i];
    }
    var serverAction = "newevent";
    $.get("update.jsp", {
        /*Tagparameter in der update.jsp für newevent nicht gefunden */
        action: serverAction, name: betreff, dtStart: zeitAnf, dtEnd: zeitEnd, location: location,
        comment: commentar, url: url, alarmMin: alarmMin, repeatType: repeatType, repeatUntil: repeatUntil, tags: tags
    }, function (data) {
        if (!hasValue(data, status) && data.status.toLowerCase() == 'ok') {
            actionSuccess();
        } else {
            actionFailed();
        }
    }, "json").fail(actionFailed());


    /*   Offline: Daten zum Array hinzufügen und davor gleichen Datensatz löschen  */
    var EventObj = {"name": betreff, "dtStart": zeitAnf, "dtEnd": zeitEnd, "location": location,
        "comment": commentar, "url": url, "alarmMin": alarmMin, "repeatType": repeatType, "repeatUntil": repeatUntil, "tags": tags}

    $.each(jsonevents.events, function(i){
        if(jsonevents.events[i].name === betreff) {
            jsonevents.events.splice(i,1);
            return false;
        }
    });

    jsonevents.events.push(EventObj);
    updateData();
    showEvents();
    showFormular("");
};


